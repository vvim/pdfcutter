#ifndef CHAPTERNAMING_H
#define CHAPTERNAMING_H


struct chapternaming {
    QString booktitle;
    QString studentlevel;
    QString manualtype;
    QString chapter;
    int pagerange_start, pagerange_end; // obsolete?
    QString pagerange;
};

#endif // CHAPTERNAMING_H
